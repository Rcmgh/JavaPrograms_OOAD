import java.util.*;

public class ATM {
    public static void main(String[] args) {
        // Create the chain of responsibility
        TransactionProcessor manager = new Manager();
        TransactionProcessor vicePresident = new VicePresident();
        TransactionProcessor ceo = new CEO();
        manager.setSuccessor(vicePresident);
        vicePresident.setSuccessor(ceo);

        // Transactions to be approved
        Transaction transaction1 = new Transaction(2600000.0, "Withdrawal");
        Transaction transaction2 = new Transaction(50000.0, "Withdrawal");
        Transaction transaction3 = new Transaction(120000.0, "Deposit");
        Transaction transaction4 = new Transaction(1500000.0, "Transfer");
        Transaction transaction5 = new Transaction(0.0, "Withdrawal");

        // Process the transactions
        manager.approve(transaction1);
        manager.approve(transaction2);
        manager.approve(transaction3);
        manager.approve(transaction4);
        manager.approve(transaction5);
    }
}

abstract class TransactionProcessor {
    private TransactionProcessor successor;

    abstract protected Double getApprovalLimit();

    abstract protected String getDesignation();

    public void setSuccessor(TransactionProcessor successor) {
        this.successor = successor;
    }

    public void approve(Transaction transaction) {
        if (transaction.getAmount() <= 0.0) {
            System.out.println("Invalid Amount. Amount should be > 0");
            return;
        }
        if (transaction.getAmount() <= getApprovalLimit()) {
            System.out
                    .println(transaction.getPurpose() + " transaction for amount " + transaction.getAmount() + " approved by " + getDesignation());
        } else {
            if (successor == null) {
                System.out.println("Transaction amount exceeds limit. Transaction cannot be approved.");
                return;
            }
            successor.approve(transaction);
        }
    }
}

class Manager extends TransactionProcessor {

    @Override
    protected Double getApprovalLimit() {
        return 100.0;
    }

    @Override
    protected String getDesignation() {
        return "Manager";
    }
}

class VicePresident extends TransactionProcessor {

    @Override
    protected Double getApprovalLimit() {
        return 500.0;
    }

    @Override
    protected String getDesignation() {
        return "Vice President";
    }
}

class CEO extends TransactionProcessor {

    @Override
    protected Double getApprovalLimit() {
        return 2000.0;
    }

    @Override
    protected String getDesignation() {
        return "CEO";
    }
}

class Transaction {
    private Double amount;
    private String purpose;

    Transaction(Double amount, String purpose) {
        this.amount = amount;
        this.purpose = purpose;
    }

    public Double getAmount() {
        return amount;
    }

    public String getPurpose() {
        return purpose;
    }
}
