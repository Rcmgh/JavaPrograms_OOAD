class CPUTest
{
	public static void main(String[] args)
	{
		ComputerFacade cf = new ComputerFacade();
		cf.start();
		
	}
}