interface PackageFacade
{
	void book();
}