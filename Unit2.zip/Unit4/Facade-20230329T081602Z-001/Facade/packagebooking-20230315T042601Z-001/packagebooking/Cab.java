class Cab implements CabBooking
{
	public void book()
	{
		System.out.println("Cab booked successfully");
	}
}