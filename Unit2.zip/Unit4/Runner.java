import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RaceSimulator {

    private static int numRunners;
    private static List<Runner> runners;

    public static void main(String[] args) {
        // Get number of runners from command line argument
        System.out.println("Login name: " + System.getProperty("user.name"));
        System.out.println("IP address: " + InetAddress.getLocalHost().getHostAddress());
        if (args.length == 0) {
            System.out.println("Please specify the number of runners.");
            return;
        }
        numRunners = Integer.parseInt(args[0]);
        if (numRunners <= 0) {
            System.out.println("Number of runners must be positive.");
            return;
        }

        // Create list of runners
        runners = new ArrayList<>();
        for (int i = 1; i <= numRunners; i++) {
            runners.add(new Runner("Runner " + i));
        }

        // Start threads for each runner
        for (Runner runner : runners) {
            runner.start();
        }

        // Wait for one runner to finish
        for (Runner runner : runners) {
            try {
                runner.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Print top 3 runners
        Collections.sort(runners);
        System.out.println("Top 3 runners:");
        for (int i = 0; i < Math.min(3, runners.size()); i++) {
            Runner runner = runners.get(i);
            System.out.printf("%d. %s (distance: %d meters)%n", i + 1, runner.getName(), runner.getDistance());
        }
    }

    static class Runner extends Thread implements Comparable<Runner> {

        private String name;
        private int distance;

        public Runner(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public int getDistance() {
            return distance;
        }

        @Override
        public void run() {
            while (distance < 1000) {
                // Sleep for 1 second
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // Update distance
                int distanceCovered = (int) (Math.random() * 6 + 5); // Random distance between 5-10 meters
                distance += distanceCovered;

                // Print distance
                System.out.printf("%s: %d meters%n", name, distance);
            }
        }

        @Override
        public int compareTo(Runner o) {
            return Integer.compare(o.distance, this.distance);
        }
    }
}
