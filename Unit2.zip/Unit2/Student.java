//Java Program to demonstrate the use of static variables.
class Student{
    int rollno;
    String name;
    static String college = "PESU"; //static variables

    Student(int r,String n){
        rollno = r;
        name = n;
    }

void display(){
    System.out.println(rollno + " "+ name + " " + college);}

}

public class Teststaticvariable{
    public static void main(String args[]){
        Student s1 = new Student(123,"hAMU");
        Student s2 = new Student(456,"abu");

        Student.college="PE UNIVERSITY";

        s1.display();
        s2.display(); 
    }
}



//Java Program to illustrate the use of static variable which is shared with all objects.
class Counter2{
    static int count=0;
}