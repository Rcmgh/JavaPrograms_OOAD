//Inheritance Types
class A{
    int a;
    void methodA(){
        System.out.println("methodA" + a);
    }
    void methodC(){
        System.out.println("Class A's:methodC"); 
    }
}

class B extends A{
    void methodB(){
        System.out.println("methodB");
    }
    void methodC(){
       System.out.println("Class B's:methodC"); 
    }
}

class Inheritance_Demo{
     public static void main(String[]args){
        A o1 = new A();
        o1.a = 5;
        o1.methodA();
        o1.methodC();

        B o2 = new B();
        o2.a = 10;
        o2.methodA();
        o2.methodB();
        o2.methodC();
        
        A o3 = new B(); // a new object of class B is created and assigned to vaiable obj. This Variable is actually of type class A. However, B
                        //is derived from class A and hence will work. A super class reference variable can 
        o3.methodA();
        //o3.methodB();  //Error: o3 is variable of type class A
        o3.methodC();

        //B o3 = new A();  //Error: class A cannot be converted to class B.

     }
     }
