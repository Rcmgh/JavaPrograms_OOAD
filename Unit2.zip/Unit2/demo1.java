public class Person {
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void introduce() {
        System.out.println("My name is " + name + " and age is " + age);
    }
}

public class Student extends Person {
    protected int studentId;

    public Student(String name, int age, int studentId) {
        super(name, age);
        this.studentId = studentId;
    }

    @Override
    public void introduce() {
        super.introduce();
        System.out.println("I am a student with student id: " + studentId);
    }
}

public class GraduateStudent extends Student {
    private String thesisTitle;

    public GraduateStudent(String name, int age, int studentId, String thesisTitle) {
        super(name, age, studentId);
        this.thesisTitle = thesisTitle;
    }

    @Override
    public void introduce() {
        super.introduce();
        System.out.println("I am a graduate student and my thesis title is \"" + thesisTitle + "\"");
    }
}

public class Teacher extends Person {
    private String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    @Override
    public void introduce() {
        super.introduce();
        System.out.println("I am a teacher and I teach " + subject);
    }
}
