import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read input for Person
        String name = scanner.next();
        int age = scanner.nextInt();
        Person person = new Person(name, age);
        person.introduce();

        // Read input for Student
        name = scanner.next();
        age = scanner.nextInt();
        int studentId = scanner.nextInt();
        Student student = new Student(name, age, studentId);
        student.introduce();

        // Read input for GraduateStudent
        name = scanner.next();
        age = scanner.nextInt();
        studentId = scanner.nextInt();
        String thesisTitle = scanner.next();
        GraduateStudent graduateStudent = new GraduateStudent(name, age, studentId, thesisTitle);
        graduateStudent.introduce();

        // Read input for Teacher
        name = scanner.next();
        age = scanner.nextInt();
        String subject = scanner.next();
        Teacher teacher = new Teacher(name, age, subject);
        teacher.introduce();

        scanner.close();
        System.out.println("fin");
    }
}

// Person class
class Person {
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    protected void introduce() {
        System.out.println("My name is " + name + " and my age is " + age);
    }
}

// Student class
class Student extends Person {
    protected int studentId;

    public Student(String name, int age, int studentId) {
        super(name, age);
        this.studentId = studentId;
    }

    @Override
    protected void introduce() {
        super.introduce();
        System.out.println("I am a student with student ID : " + studentId);
    }
}

// GraduateStudent class
class GraduateStudent extends Student {
    private String thesisTitle;

    public GraduateStudent(String name, int age, int studentId, String thesisTitle) {
        super(name, age, studentId);
        this.thesisTitle = thesisTitle;
    }

    @Override
    protected void introduce() {
        super.introduce();
        System.out.println("I am a graduate student and my thesis title is " + thesisTitle);
    }
}

// Teacher class
class Teacher extends Person {
    private String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    @Override
    protected void introduce() {
        super.introduce();
        System.out.println("I am a teacher and I teach " + subject);
    }
}