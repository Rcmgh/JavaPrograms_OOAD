import java.util.*;
public class Primes {
    boolean prime(int x) {
        if (x == 1) return false;
        for(int i = 2; i < x; i++)
            if (x % i == 0) return false;
        return true;
    }

    int isPrime(int a, int b) {
        boolean isPrimeA = prime(a);
        boolean isPrimeB = prime(b);

        if (!isPrimeA && !isPrimeB)  return 0;
        if (isPrimeA && !isPrimeB) return 1;
        if (!isPrimeA && isPrimeB) return 2;
        if (isPrimeA && isPrimeB && (a - b == 2 || b - a == 2)) return 4;
        return 3;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int b = in.nextInt();

        Primes p = new Primes();

        System.out.println(p.isPrime(a, b));
        in.close();
    }
}