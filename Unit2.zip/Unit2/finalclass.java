//if you make any class as final,you cannot extend it.
final class Bike{}
   class Honda1 extends Bike{
    void run(){System.out.println("Runninnh");}
    public static void main(String arga[]){
        Honda1 honda = new Honda1();
        honda.run();
    }
   }