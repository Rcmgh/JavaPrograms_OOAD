import java.util.ArrayList;
import java.util.Collections;


class ArrayLists{
    public static void main(String[] args){
        ArrayyList<Integer> list = new ArrayList<Integer>;
        ArrayyList<Integer> list = new ArrayList<Integer>;
        ArrayyList<Integer> list = new ArrayList<Integer>;
        for(i=0,i<array.length,i++){
            System.out.println("ArrayaList is declared")
        }
            System.out.println("Element is added to the list:")
    }
}