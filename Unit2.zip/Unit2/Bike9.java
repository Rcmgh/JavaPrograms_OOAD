class Bike9{
    final int speedlimit = 90;
    void run(){
        Speedlimit = 400;
    }
    public static void main finalvar(String args[]){
        Bike9 obj = new Bike9();
        obj.run();
    }
}

