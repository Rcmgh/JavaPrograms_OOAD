// Abstract class with both abstract and non abstrct methods
abstract methods
abstract class Bike{
    Bike(){System.out.println("bike is created");}
    abstract void run();
    void changeGeat(){System.out.println("gear changes");}
}

class Honda extends Bike{
    void run(){System.out.println("running safely..");}

}

abstract methods
class TestAbstraction2{
    public static void main(String args[]){
        Bike obj = new Honda();
        obj.run();
        obj.changeGeat();
        
    }
}