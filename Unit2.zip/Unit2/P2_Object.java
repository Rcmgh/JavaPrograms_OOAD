class Box{
    int widht;
    int height;
    int depth;
    Box()
    {
        this width=0;this.height = 0; this.depth = 0;
    }
    Box(int l, int m,int n)
    {
       this width=l;this.height = m; this.depth = n; 
    }
    //Override
    public boolean equals(Object o){
        Box b2 = (Box) o;
        return this.width == b2.width && this.height == b2.height && this.depth ==b2.depth;
    }
}

public class P2_Object{
    public static void main(String[] args){
        Box.obj1 = new Box();
        Box.obj1 = new Box();
        Box.obj1 = new Box();
    }
}