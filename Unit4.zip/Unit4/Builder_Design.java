public class Car{
    private String make;
    private String model;
    private String year;
    private int doors;
    private boolean hasSunroof;
    private String CarType;


/* private Car(Carbuilder builder)
{
    this.make = builder.make;
    this.model = builder.model;
    this.year = builder.year;
    this.doors = builder.door;
    this.hasSunroof = builder.hasSunroof;
    this.CarType = builder.CarType; */


public Carbuilder(String make, String model,String year){
    this.make = make;
    this.model = model;
    this.year = year;
    return this;
    return this;
    return this;

}

public Carbuilder setDoors(int doors){
    this.doors = doors;
    return this;
}

public Carbuilder setHasSunroof(boolean hasSunroof){
    this.hasSunroof = hasSunroof;
    return this;
}
 
public Carbuilder setCarType(String CarType){
    this.CarType = CarType;
    return this;
}

public Car build(){
    return new Car(this);
}
}


public class Builder_Design{
    public static void main(String args[]){
        Car carobj =  new Car.Carbuilder("Ford","Mustang","2020");
        System.out.println(carobj);
        Car carobj =  new Carbuilder.setDoors(4);
        System.out.println(carobj);
        Car carobj =  new Car.setHasSunroof(true);
        System.out.println(carobj);
        Car carobj =  new Car.build();
        System.out.println(carobj);
    
    }
}





