interface HotelBooking
{
	void book();
}