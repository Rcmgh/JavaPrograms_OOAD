interface FlightBooking
{
	void book();
}