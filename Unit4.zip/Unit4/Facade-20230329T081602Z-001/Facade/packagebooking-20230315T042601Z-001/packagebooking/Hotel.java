class Hotel implements HotelBooking
{
	public void book()
	{
		System.out.println("Hotel booked successfully");
	}
}