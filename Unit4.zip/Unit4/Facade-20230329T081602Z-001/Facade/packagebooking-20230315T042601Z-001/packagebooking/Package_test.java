class Package_test
{
	public static void main(String[] args)
	{
		
		PackageFacade pf = new PackageFacadeImpl();
		pf.book();
		
	}
}