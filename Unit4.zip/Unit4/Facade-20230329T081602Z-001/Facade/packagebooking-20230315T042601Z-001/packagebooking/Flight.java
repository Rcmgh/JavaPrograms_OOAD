class Flight implements FlightBooking
{
	public void book()
	{
		System.out.println("Flight booked successfully");
	}
}